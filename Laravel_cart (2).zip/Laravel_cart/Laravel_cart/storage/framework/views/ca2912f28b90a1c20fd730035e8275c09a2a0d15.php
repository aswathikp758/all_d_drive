<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title></title>
</head>
<body>
  <div class="container">
  <form method="post" action="<?php echo e(route('products.store')); ?>" 
    enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="image">
      <input type="text" placeholder="Product" name="product" class="form-control">
      <input type="number" name="price" placeholder="Price" class="form-control">
      <input type="number" name="quantity" placeholder="Quantity" class="form-control">
      <input type="text" name="desc" placeholder="Details" class="form-control">
      <input type="file" class="form-control" required name="image">
    </div>

    <div class="post_button">
      <button type="submit" class="btn btn-success">Add</button>
    </div>
  </form>
</div>

</body>
</html><?php /**PATH D:\Laravel_cart\resources\views/add_product.blade.php ENDPATH**/ ?>