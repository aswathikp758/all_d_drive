<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title></title>
</head>
<body>
<div class="container">
    <h3>View all image</h3><hr>
    <table class="table">
      <thead>
        <tr>
          <th scope="col">Image id</th>
           <th scope="col">Image</th>
          <th scope="col">Product</th>
          <th scope="col">price</th>
          <th scope="col">Description</th>
           <th scope="col">Action</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td>
       <img src="<?php echo e(url('public/Image/'.$data->image)); ?>"
 style="height: 100px; width: 150px;">
    </td>
          <td><?php echo e($data->name); ?></td>
          <td><?php echo e($data->price); ?></td>
          <td><?php echo e($data->description); ?></td>
          <td><a href="<?php echo e(route('cart.store')); ?>">Add to cart</a></td>
          <td><a href="#">Buy now</a></td>
         
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
</body>
</html><?php /**PATH D:\Laravel_cart\resources\views/index.blade.php ENDPATH**/ ?>