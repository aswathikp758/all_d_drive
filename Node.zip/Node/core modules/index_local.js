// const sayHello=require("./Local_module");
// sayHello();


//Anomymous function call
// const hello=require("./Local_module");
// hello();

//object function call
const hello=require("./Local_module");
console.log(hello.name);
console.log(hello.place);
hello.greet();