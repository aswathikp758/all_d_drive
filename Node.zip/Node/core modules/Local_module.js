// function sayHello(){
//     console.log("Hello Good Morning");
// }
// module.exports=sayHello;



//Anonymous function

// const hello=function(){
//     console.log("Hello Good Morning");
// };
// module.exports=hello;


//Value passing like javascript oblect
 
const hello={
    name:'John',
    place:'Calicut',
    greet:function(){
        console.log(`i am ${this.name}  from ${this.place}`);
    },
};
module.exports=hello;
