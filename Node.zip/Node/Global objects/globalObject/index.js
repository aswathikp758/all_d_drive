console.log();
// object for printing
console.clear();
//for clear
console.log(_filename);
//get complete path of file
console.log(__diname);
//get directory name

const http=require('http');
//require is a global object.
setInterval(
    function(){
        console.log("Node js");
    },3000);

    //setInterval is a global object

setTimeout(function(){
    console.log("Node js");
} ,1000);

setTimeout(()=>{console.log("node js");},
1000);

//clear set intervel

const si=setInterval(function(){
    console.log("Node js");
},1000);

setTimeout(clearInterval(si),4000);