var fs=require('fs');

//Read file
fs.readFile("./test.txt","utf-8",function(err,data){
    if(err){
        console.error(err);
    }
    console.log(data);
});

//create file
// fs.writeFile(
//     'new text',
//     'Thisis a file created by node js',
//     (err)=>{
//       if(err){
//         console.log(err);
//       }
//       console.log("File Created");
//     }
// );


//append file
fs.appendFile(
    'new text',
    'This is a file created by node js',
    (err)=>{
      if(err){
        console.log(err);
      }
      console.log("File Created");
    }
);
//Rename files
fs.rename('./test.txt','sample.txt',(err)=>{
    if(err){
        console.log('File renamed');
    }
});

//Delete files
fs.unlink('./new.txt',(err)=>{
    if(err){
        console.log('File Deleted');
    }
});