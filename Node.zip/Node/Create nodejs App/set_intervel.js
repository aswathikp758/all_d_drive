// setInterval(()=>{
//     console.log("Running");
// },1000);

//setIntervel function has 2 parameter .one is arrow function,
//and other one is time intervel.
// output printing each 1 second 
//after getting output.stop the execution.Because this function is 
//continously running.

setTimeout(()=>{
    console.log("Running");
},2000);

//setTimeout is another function.using for set how many time after run the program


//HOW TO CLEAR setIntervel()

const intervel=setInterval(()=>{
    console.log("Running");
},1000);

setTimeout(()=>{
    clearInterval(interval);
},3000);