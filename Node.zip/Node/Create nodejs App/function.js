function newfunc(){
    return 10;
}
console.log(newfunc());

// Arrow function
// const newFun = () =>10;
// console.log(newFun());