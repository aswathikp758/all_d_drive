const array=["a","b","c"];

array.push("d");
console.log(array);

