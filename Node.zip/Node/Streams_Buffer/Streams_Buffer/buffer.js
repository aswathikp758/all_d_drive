const buf =Buffer.from("Hey");
console.log(buf);
console.log(buf[0]);